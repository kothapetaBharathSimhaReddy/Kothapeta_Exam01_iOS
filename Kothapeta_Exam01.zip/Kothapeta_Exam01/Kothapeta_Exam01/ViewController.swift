//
//  ViewController.swift
//  Kothapeta_Exam01
//
//  Created by Bharath Simha Reddy Kothapeta on 9/26/24.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var InputofAgricultural: UITextField!
    
    @IBOutlet weak var InputofElectricity: UITextField!
    
    @IBOutlet weak var DisplayImage: UIImageView!
    
    @IBOutlet weak var DisplayTest1: UILabel!
    
    @IBOutlet weak var DisplayTest2: UILabel!
    
    @IBOutlet weak var DisplayTest3: UILabel!
    
    @IBOutlet weak var DisplayTest4: UILabel!
    
    @IBOutlet weak var DisplayTest5: UILabel!
    
    @IBOutlet weak var DisplayText: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        clearResults()
        
    }
    
    
    @IBAction func CarbonButton(_ sender: UIButton) {
        
        // Validate input fields
        guard let location = InputofAgricultural.text, !location.isEmpty else {
            DisplayTest1.text = "Please enter a valid agricultural location."
            return
        }
        
        guard let electricityText = InputofElectricity.text, let electricity = Int(electricityText), electricity >= 0 && electricity <= 10000 else {
            DisplayTest1.text = "Please enter electricity consumption between 0 and 10000 kWh."
            return
        }
        
        // Clear any previous error messages
        DisplayTest1.text = ""
        
        // Perform the calculation
        let (footprintRange, drivingFactors, imageName) = calculateCarbonFootprint(electricity: electricity)
        
        // Display the results in labels
        DisplayTest1.text = "Location: \(location)"
        DisplayTest2.text = "Electricity Consumed: \(electricity) kWh"
        DisplayTest3.text = "Carbon Footprint Range: \(footprintRange)"
        DisplayTest4.text = "Driving Factors: \(drivingFactors)"
        
        // Display the corresponding image based on the footprint range
        DisplayImage.image = UIImage(named: imageName)
    }
    
    @IBAction func ResetButton(_ sender: UIButton) {
        InputofAgricultural.text = ""
        InputofElectricity.text = ""
        clearResults()
    }
    
    // Method to clear result labels and image
    func clearResults() {
        DisplayTest1.text = ""
        DisplayTest2.text = ""
        DisplayTest3.text = ""
        DisplayTest4.text = ""
        DisplayTest5.text = ""
        DisplayImage.image = nil
        
    }
    
    // Function to calculate the carbon footprint based on electricity consumption
    
    func calculateCarbonFootprint(electricity: Int) -> (String, String, String) {
        if electricity < 3000 {
            return ("Low", "Efficient usage, renewable energy", "LowCarbonFootprint.jpg")
        } else if electricity < 7000 {
            return ("Medium", "Moderate usage, partial renewables", "MediumCarbonFootprint.jpg")
        } else {
            return ("High", "High usage, non-renewable sources", "HighCarbonFootprint.png")
        }
    }
}
